package com.corecraft;
import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.StyleRes;

import java.time.LocalDateTime;

public class CustomDatePickerDialog extends DatePickerDialog {

    public CustomDatePickerDialog(Context context,@StyleRes int themeResId, OnDateSetListener listener, int year, int month, int dayOfMonth) {
        super(context, themeResId, listener, year, month, dayOfMonth);
    }
    @Override
    public void onDateChanged(@NonNull DatePicker view, int year, int month, int dayOfMonth) {
        super.onDateChanged(view, year, month, dayOfMonth);

        int selectedDay = view.getDayOfMonth();
        int selectedMonth = view.getMonth() + 1;
        int selectedYear = view.getYear();
//        getDatePicker().init(year,month,dayOfMonth,this);
//        Plan.PLANS.forEach(p -> {
//            final long time = p.getDate().getTime();
//            Toast.makeText(getContext(),String.valueOf(time),Toast.LENGTH_SHORT).show();
//            getDatePicker().init(p.getDate().getYear(),p.getDate().getMonth(),p.getDate().getDay(),this);
//        });
        if (selectedDay == 1 && selectedMonth == 1 && selectedYear == 2025) {
            view.findViewById(getContext().getResources().getIdentifier("numberpicker_input", "id", "android")).setBackgroundColor(Color.RED);
        }
    }
}